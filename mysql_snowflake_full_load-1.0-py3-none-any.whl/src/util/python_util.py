import threading
from datetime import datetime


def print_message(message):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    thread_name = threading.current_thread().name
    thread_name = thread_name if '_' not in thread_name else f"Thread-{int(thread_name.split('_')[1])+1}"
    print("[{}] [INFO]  [{}]    {}".format(current_time, thread_name, message))


def print_error(message):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    thread_name = threading.current_thread().name
    thread_name = thread_name if '_' not in thread_name else f"Thread-{int(thread_name.split('_')[1])+1}"
    print("[{}] [ERROR] [{}]    {}".format(current_time, thread_name, message))


def print_warning(message):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    thread_name = threading.current_thread().name
    thread_name = thread_name if '_' not in thread_name else f"Thread-{int(thread_name.split('_')[1])+1}"
    print("[{}] [WARN]  [{}]    {}".format(current_time, thread_name, message))
