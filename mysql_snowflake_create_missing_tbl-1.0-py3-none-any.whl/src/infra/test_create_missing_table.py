import os

import boto3
import unittest

import definitions
import pytest
from moto import mock_s3
from unittest.mock import patch

from src.etl.create_missing_table import main
from tests.util import sf_df_query, read_spark_local, write_sf_dataframe, read_mysql_query, read_mysql_dataframe
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("example").getOrCreate()

@mock_s3
@pytest.mark.unit
class MainTest(unittest.TestCase):

    def init(self):
        pass

    def getResolvedOptions(self):
        return None

    def setup_mocked_infra(self):
        pass

    @patch('src.infra.extract.Extract.read_mysql_dataframe')
    @patch('src.infra.extract.Extract.read_mysql_query')
    @patch('src.etl.validation.spark')
    @patch('src.infra.write.Write.write_sf_dataframe')
    @patch('src.infra.extract.Extract.read_dataframe_s3')
    @patch('src.infra.extract.Extract.read_sf_query')
    def test_main(self, mock_read_sf_query, mock_read_dataframe_s3, mock_write_sf_dataframe, mock_spark, mock_read_mysql_query, mock_read_mysql_dataframe):
        self.setup_mocked_infra()
        mock_read_sf_query.side_effect = lambda glue_context, snowflake_connection_name, snowflake_database, query: sf_df_query(query)
        mock_read_dataframe_s3.side_effect = lambda spark, schema_table, s3_src_bucket_name, object_name: read_spark_local(s3_src_bucket_name, object_name) if True else None
        mock_write_sf_dataframe.side_effect = lambda glue_context, snowflake_connection_name, df, snowflake_database, schema_table, object_name, pre_action, post_action: write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database, schema_table, pre_action,post_action) if True else None
        mock_spark.return_value = spark
        mock_read_mysql_query.side_effect = lambda glue_context, mysql_connection_name, query: read_mysql_query(query)
        mock_read_mysql_dataframe.side_effect = lambda glue_context, mysql_connection_name, schema_table: read_mysql_dataframe(schema_table)
        main()

