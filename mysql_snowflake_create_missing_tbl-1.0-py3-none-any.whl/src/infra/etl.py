from src.infra.extract import Extract
from src.infra.s3 import S3
from src.infra.transform import Transform
from src.infra.write import Write
from src.util.python_util import print_message, print_warning
from pyspark.sql.functions import *


def get_primary_keys(meta_data, schema_table, object_name, df):
    table_join_keys = meta_data.get('table_join_keys')
    table_name = schema_table.split('.')[1]
    primary_keys = table_join_keys.get(table_name)
    if not primary_keys:
        primary_keys = Transform.auto_detect_id_column(df)
        print_warning(
            f"[{schema_table}]  [{object_name}]    primary_keys not found. so auto detected primary_keys is {primary_keys}")
    else:
        print_message(f"[{schema_table}]  [{object_name}]    given primary_keys {primary_keys}")
    return primary_keys


def merge_data(df, object_name, schema_table, meta_data, primary_keys, target_sf_columns):
    glue_context = meta_data.get('glue_context')
    snowflake_connection_name = meta_data.get('snowflake_connection_name')
    snowflake_database = meta_data.get('snowflake_database')
    # sf_meta_data = Transform.get_sf_meta(glue_context, snowflake_connection_name, snowflake_database, schema_table, object_name)
    pre_action, target_sf_columns = Transform.create_missing_columns(df.drop('op'), target_sf_columns, schema_table, object_name)
    merge_query = Transform.get_merge_query(schema_table, object_name, primary_keys, df.columns)
    post_action = merge_query + f"DROP TABLE IF EXISTS {schema_table}_stage;"
    Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database, f"{schema_table}_stage",
                             object_name,
                             pre_action, post_action)
    return target_sf_columns


def perform_merge_or_fresh_load(available_sf_table, schema_table, df, object_name, meta_data, primary_keys, target_sf_columns):
    glue_context = meta_data.get('glue_context')
    snowflake_connection_name = meta_data.get('snowflake_connection_name')
    snowflake_database = meta_data.get('snowflake_database')
    support_schema = meta_data.get('snowflake_support_schema')
    spark = meta_data.get('spark')
    if schema_table in available_sf_table:
        print_message(f"[{schema_table}]  [{object_name}]    Table already present. Merge the data")
        target_sf_columns = merge_data(df, object_name, schema_table, meta_data, primary_keys, target_sf_columns)
    else:
        print_message(f"[{schema_table}]  [{object_name}]    Table not present. Load fresh data")
        schema_name = schema_table.split('.')[0]
        temp_schema_table = f"{support_schema}.{schema_name}_temp"
        temp_post_action = f"CREATE SCHEMA IF NOT EXISTS {schema_table.split('.')[0].upper()}; DROP TABLE IF EXISTS {temp_schema_table};"
        temp_df = spark.createDataFrame([{"id": 1}])
        Write.write_sf_dataframe(glue_context, snowflake_connection_name, temp_df, snowflake_database,
                                 temp_schema_table, object_name,
                                 None, temp_post_action)
        Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                 schema_table, object_name,
                                 None, None)
        available_sf_table.add(schema_table)
        target_sf_columns = df.columns
    return available_sf_table, target_sf_columns


def clean_df(schema_table, object_name, df, primary_keys):
    df = Transform.add_synced_column(df)
    df = Transform.clean_column_name(schema_table, object_name, df)
    df = Transform.parse_invalid_dtypes(schema_table, object_name, df)
    df = Transform.parse_to_string(schema_table, object_name, df, primary_keys)
    return df


def perform_delete(available_sf_table, df, object_name, schema_table, meta_data, primary_keys):
    df_delete = df.where(df['op'] == 'D').drop('op')
    if df_delete.count() > 0:
        if schema_table in available_sf_table:
            glue_context = meta_data.get('glue_context')
            snowflake_connection_name = meta_data.get('snowflake_connection_name')
            snowflake_database = meta_data.get('snowflake_database')
            print_message(f"[{schema_table}]  [{object_name}]    Found delete records. count: {df_delete.count()}")
            delete_query = Transform.get_delete_query(schema_table, object_name, primary_keys)
            post_action = delete_query + f"DROP TABLE IF EXISTS {schema_table}_delete_stage;"
            Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                     f"{schema_table}_delete_stage", object_name,
                                     None, post_action)
        else:
            print_warning(
                f"[{schema_table}]  [{object_name}]    No Table found but received delete records. Since skipping delete ")

    else:
        print_warning(f"[{schema_table}]  [{object_name}]    No records found for delete")


def perform_full_load(schema_table, files, meta_data, available_sf_table, target_sf_columns):
    s3_src_bucket_name = meta_data.get('s3_src_bucket_name')
    aws_region = meta_data.get('aws_region')
    spark = meta_data.get('spark')
    full_load_files = files.get('full_load', [])
    print_message(f'[{schema_table}]  Total files found for full load count : {len(full_load_files)}')
    if len(full_load_files) <= 0:
        print_warning(f"[{schema_table}]  No Files found for full load")
    for idx, object_name in enumerate(sorted(full_load_files)):
        print_message(f"[{schema_table}]  [{object_name}]    Started processing")
        df = Extract.read_dataframe_s3(spark, schema_table, s3_src_bucket_name, object_name)
        if df.count() > 0:
            primary_keys = get_primary_keys(meta_data, schema_table, object_name, df.drop('op'))
            df = Transform.get_unique_records(df, primary_keys)
            df = clean_df(schema_table, object_name, df, primary_keys)
            available_sf_table, target_sf_columns = perform_merge_or_fresh_load(available_sf_table, schema_table, df, object_name,
                                                             meta_data, primary_keys, target_sf_columns)
        else:
            print_warning(f"[{schema_table}]  [{object_name}]    Empty file found")
        S3.move_s3_file(schema_table, s3_src_bucket_name, object_name, meta_data.get('s3_archive_bucket_name'),
                        object_name,
                        aws_region)
        print_message(f"[{schema_table}]  [{object_name}]    Completed processing")
    return available_sf_table, target_sf_columns


def perform_cdc(schema_table, files, meta_data, available_sf_table, target_sf_columns):
    s3_src_bucket_name = meta_data.get('s3_src_bucket_name')
    aws_region = meta_data.get('aws_region')
    spark = meta_data.get('spark')
    incremental_load_files = files.get('incremental_load', [])
    print_message(f'[{schema_table}]  Total files found for cdc load. count : {len(incremental_load_files)}')
    if len(incremental_load_files) <= 0:
        print_warning(f"[{schema_table}]  No Files found for cdc load")
    for idx, object_name in enumerate(sorted(incremental_load_files)):
        df = Extract.read_dataframe_s3(spark, schema_table, s3_src_bucket_name, object_name)
        if df.count() > 0:
            primary_keys = get_primary_keys(meta_data, schema_table, object_name, df.drop('op'))
            df = Transform.get_unique_records(df, primary_keys)
            df = clean_df(schema_table, object_name, df, primary_keys)
            if 'op' not in df.columns:
                df = df.withColumn('op', lit('I'))
            perform_delete(available_sf_table, df, object_name, schema_table, meta_data, primary_keys)
            df_upsert = df.where(df['op'] != 'D').drop('op')
            if df_upsert.count() > 0:
                print_message(f"[{schema_table}]  [{object_name}]    Found upsert records. count: {df_upsert.count()}")
                available_sf_table, target_sf_columns = perform_merge_or_fresh_load(available_sf_table, schema_table, df_upsert,
                                                                 object_name,
                                                                 meta_data, primary_keys, target_sf_columns)
            else:
                print_warning(f"[{schema_table}]  [{object_name}]    No records found for upsert")
        else:
            print_warning(f"[{schema_table}]  [{object_name}]    Empty file found.")
        S3.move_s3_file(schema_table, s3_src_bucket_name, object_name, meta_data.get('s3_archive_bucket_name'),
                        object_name,
                        aws_region)


def perform_etl(schema_table, files, meta_data, sf_meta_data):
    print_message(f"[{schema_table}]  ETL Started")
    available_sf_table = meta_data.get('available_sf_table')
    schema_name = schema_table.split('.')[0]
    table_name = schema_table.split('.')[1]
    target_sf_columns = [row["column_name"] for row in sf_meta_data.where(col('table_schema') == schema_name.lower()).where(col('table_name') == table_name.lower()).collect()]
    print_message(f"[{schema_table}]  target_sf_columns: {target_sf_columns}")
    available_sf_table, target_sf_columns = perform_full_load(schema_table, files, meta_data, available_sf_table, target_sf_columns)
    perform_cdc(schema_table, files, meta_data, available_sf_table, target_sf_columns)
