import os

from src.infra.etl import perform_etl
from src.infra.extract import Extract
from src.infra.s3 import S3
from src.infra.thread import Threading
from src.util.python_util import print_warning, print_message, print_error

try:
    from awsglue.transforms import *
    from awsglue.context import GlueContext
    from awsglue.job import Job
    from awsglue.utils import getResolvedOptions
except Exception as e:
    print_error(str(e))

from pyspark.sql.functions import *

glue_context = None
spark = None

try:
    args = getResolvedOptions(sys.argv, ["JOB_NAME"])
    sc = SparkContext()
    glue_context = GlueContext(sc)
    spark = glue_context.spark_session
    job = Job(glue_context)
    job.init(args["JOB_NAME"], args)
except Exception as e:
    print_error(str(e))

def main():
    print_message("Started the process...")
    print_message('Setting up config values...')

    s3_src_bucket_name = 'sf-postgres'
    s3_src_bucket_prefix = ['']
    s3_archive_bucket_name = 'sf-postgres-archive'
    aws_region = 'ap-south-1'
    snowflake_connection_name = 'Snowflake connection'
    snowflake_database = 'test'
    snowflake_support_schema = 'dc'

    schema_position = 1  # Give the position from s3 object key excluding bucket name
    table_position = 2

    table_join_keys = {
            "table_name_1": ["sequence"],
            "table_name_2": ["sequence"]
    }

    meta_data = {'s3_src_bucket_name': s3_src_bucket_name,
                 's3_src_bucket_prefix': s3_src_bucket_prefix,
                 's3_archive_bucket_name': s3_archive_bucket_name,
                 'aws_region': aws_region,
                 'table_join_keys': table_join_keys,
                 'snowflake_connection_name': snowflake_connection_name,
                 'snowflake_database': snowflake_database,
                 'glue_context': glue_context,
                 'spark': spark,
                 'snowflake_support_schema': snowflake_support_schema}

    thread_count = os.cpu_count()
    print_message(f"Total thread_count: {thread_count}")

    query = "SELECT lower(table_schema) as table_schema, lower(table_name) as table_name, lower(column_name) as column_name, lower(data_type) as data_type FROM information_schema.columns"
    sf_meta_data = Extract.read_sf_query(glue_context, snowflake_connection_name, snowflake_database, query)
    sf_meta_data = sf_meta_data.toDF(*[col_name.lower() for col_name in sf_meta_data.columns])

    unique_df = sf_meta_data.dropDuplicates(["table_schema", "table_name"])
    formatted_df = unique_df.withColumn("formatted_name", concat_ws(".", col("table_schema"), col("table_name")))
    available_sf_table = set(formatted_df.select("formatted_name").rdd.flatMap(lambda x: x).collect())
    meta_data['available_sf_table'] = available_sf_table

    print_message(f"available_sf_table {available_sf_table}")

    for column_t in sf_meta_data.columns:
        sf_meta_data = sf_meta_data.withColumn(column_t, lower(col(column_t)))

    all_files = S3.get_files_to_process(s3_src_bucket_name, s3_src_bucket_prefix, aws_region,
                                        schema_position, table_position)
    print_message(f'all_files : {all_files}')

    if all_files:
        print_message(f'Started thread. Total tables : {len(all_files)}')
        Threading.parallelism(perform_etl, thread_count, all_files, meta_data, sf_meta_data)
        print_message('Completed thread...')
    else:
        print_warning(f"Nothing to process. all_files: {all_files}")

    print_message("Completed the process...")


if __name__ == '__main__':
    main()
