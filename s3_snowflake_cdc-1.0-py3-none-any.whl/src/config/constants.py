

class Constants:
    pandas_snowflake_dtypes = {
        'int64': 'BIGINT',
        'object': 'VARCHAR',
        'datetime64[ns]': 'TIMESTAMP',
        'bool': 'BOOLEAN',
        'float64': 'DOUBLE PRECISION'
    }
