import os
import boto3

from src.util.python_util import print_message


class S3:

    @staticmethod
    def get_files_to_process(bucket_name, prefix_list, aws_region, schema_position, table_position):
        s3_client = boto3.client('s3', region_name=aws_region)
        all_files = {}

        prefix_list = prefix_list if prefix_list else ['']

        for prefix in prefix_list:
            print_message(f"Started fetching file info from bucket_name: '{bucket_name}', prefix: '{prefix}'")
            try:
                response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
                S3.parse_file_meta(all_files, response, schema_position, table_position)
                while response.get('IsTruncated', False):
                    response = s3_client.list_objects_v2(
                        Bucket=bucket_name,
                        Prefix=prefix,
                        ContinuationToken=response['NextContinuationToken']
                    )
                    S3.parse_file_meta(all_files, response, schema_position, table_position)
                print_message(f"Completed fetching file info. all_files: {len(all_files)}")
            except Exception as e:
                print_message(f"Error listing files in S3 bucket {bucket_name}, prefix {prefix}: {e}")
                raise e
        return all_files

    @staticmethod
    def parse_file_meta(all_files, response, schema_position, table_position):
        print_message(f"Parsing file meta from response {len(response.get('Contents', []))}")
        for obj in response.get('Contents', []):
            object_name = obj['Key']
            if str(object_name).endswith('.parquet'):
                schema = object_name.split('/')[schema_position-1]
                table = object_name.split('/')[table_position-1]
                table = f"{table}_t" if table == "all" else table
                schema_table = f"{schema.lower()}.{table.lower()}"
                if os.path.basename(str(object_name)).startswith('LOAD') and str(object_name).endswith('.parquet'):
                    all_files.setdefault(schema_table, {}).setdefault('full_load', []).append(object_name)
                elif str(object_name).endswith('.parquet'):
                    all_files.setdefault(schema_table, {}).setdefault('incremental_load', []).append(object_name)
        print_message(f"Parsing file meta from response completed. all_files: {len(all_files)}")

    @staticmethod
    def move_s3_file(schema_table, source_bucket, source_key, destination_bucket, destination_key, aws_region):
        print_message(f"[{schema_table}]  [{source_key}]    Moving S3 file from source to archive: '{source_bucket}/{source_key}' to '{destination_bucket}/{destination_key}'")
        s3_client = boto3.client('s3', region_name=aws_region)
        try:
            s3_client.copy_object(
                Bucket=destination_bucket,
                CopySource={'Bucket': source_bucket, 'Key': source_key},
                Key=destination_key
            )
            s3_client.delete_object(Bucket=source_bucket, Key=source_key)

            print_message(f"[{schema_table}]  [{source_key}]    File moved from '{source_bucket}/{source_key}' to '{destination_bucket}/{destination_key}'")
        except Exception as e:
            error_message = str(e)
            if "Insufficient privileges to operate on schema" in error_message:
                print_message(f"[{schema_table}] [{source_key}] Skipping file move due to insufficient privileges: {error_message}")
            else:
                print_message(f"[{schema_table}]  [{source_key}]    Error moving file: {e}")
