from src.infra.extract import Extract
from src.infra.s3 import S3
from src.infra.transform import Transform
from src.infra.write import Write
from src.util.python_util import print_message, print_warning
from pyspark.sql.functions import *


def get_primary_keys(meta_data, schema_table, object_name, df):
    table_join_keys = meta_data.get('table_join_keys')
    table_name = schema_table.split('.')[1]
    primary_keys = table_join_keys.get(table_name)
    if not primary_keys:
        primary_keys = Transform.auto_detect_id_column(df)
        print_warning(
            f"[{schema_table}]  [{object_name}]    primary_keys not found. so auto detected primary_keys is {primary_keys}")
    else:
        print_message(f"[{schema_table}]  [{object_name}]    given primary_keys {primary_keys}")
    return primary_keys


def get_alter_column_datatype_query(schema, tbl, column_name):
    new_column_name = f"new_{column_name}"
    alter_column_query = f"""
        ALTER TABLE "{schema}"."{tbl}" ADD COLUMN {new_column_name} VARCHAR(16777216);
        UPDATE "{schema}"."{tbl}" SET {new_column_name} = CAST({column_name} AS VARCHAR);
        ALTER TABLE "{schema}"."{tbl}" DROP COLUMN {column_name};
        ALTER TABLE "{schema}"."{tbl}" RENAME COLUMN {new_column_name} TO {column_name};"""
    return alter_column_query


def handle_numeric_value_error(schema, tbl, df, target_sf_columns, target_sf_data_types):
    mismatched_columns = []
    for column_name, source_data_type in df.dtypes:
        if source_data_type == 'string' and column_name in target_sf_columns:
            target_index = target_sf_columns.index(column_name)
            target_data_type = target_sf_data_types[target_index]
            if target_data_type in ['int', 'number']:
                mismatched_columns.append(column_name)

    alter_queries = []
    for column_name in mismatched_columns:
        alter_queries.append(get_alter_column_datatype_query(schema, tbl, column_name))
    print_message(f"handle_numeric_value_error: {alter_queries}")
    return alter_queries

def cast_columns_to_string(df, columns):
    for column in columns:
        df = df.withColumn(column, df[column].cast("string"))
    return df
def log_dataframe_schema(df, message="DataFrame Schema"):
    print_message(f"{message}: {df.dtypes}")

def merge_data(df, object_name, schema_table, meta_data, primary_keys, target_sf_columns, target_sf_data_types):
    glue_context = meta_data.get('glue_context')
    snowflake_connection_name = meta_data.get('snowflake_connection_name')
    snowflake_database = meta_data.get('snowflake_database')
    schema = schema_table.split('.')[0].upper()
    tbl = schema_table.split('.')[1].upper()

    log_dataframe_schema(df, "Initial DataFrame Schema")
    pre_action, target_sf_columns = Transform.create_missing_columns(df.drop('op'), target_sf_columns, schema_table, object_name)
    merge_query = Transform.get_merge_query(schema_table, object_name, primary_keys, df.columns)

    post_action = merge_query + f'DROP TABLE IF EXISTS "{schema}"."{tbl}_stage";'.upper()
    print_message(f"merge_data process started.")

    if pre_action is None:
        pre_action = ""  # Ensure pre_action is an empty string if it is None

    try:
        Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                 f'"{schema}"."{tbl}_stage"'.upper(), object_name,
                                 pre_action, post_action)
    except Exception as e:
        error_message = str(e)
        if "Numeric value" in error_message:
            print_warning(f"Numeric value error encountered: {error_message}")
            alter_queries = handle_numeric_value_error(schema, tbl, df, target_sf_columns, target_sf_data_types)
            for query in alter_queries:
                pre_action += query  # Append alter queries to pre_action

            # Retry the merge operation after fixing the datatype error
            Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                     f'"{schema}"."{tbl}_stage"'.upper(), object_name,
                                     pre_action, post_action)
        elif "Parquet column cannot be converted" in error_message:
            print_warning(f"Parquet column type mismatch encountered: {error_message}")
            # Identify columns causing the type mismatch
            #columns_to_cast = [column_name for column_name, source_data_type in df.dtypes if
            #                   source_data_type != 'string' and column_name in target_sf_columns]
            #df = df.withColumn('position', df['position'].cast("string"))
            # Check if 'position' column is in the columns_to_cast list
            #if 'position' in columns_to_cast:
                # Convert 'position' column to string type
            #    df = cast_columns_to_string(df, ['position'])
            #log_dataframe_schema(df, "Schema after casting columns to string")
           # print_message("Converted 'position' column to string")
            # Retry the merge operation after casting columns
            Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                     f'"{schema}"."{tbl}_stage"'.upper(), object_name,
                                     pre_action, post_action)
        else:
            print_warning(f"An error occurred for {schema_table}: {error_message}")
            # Handle other types of errors
            pass

    return target_sf_columns

# def merge_data(df, object_name, schema_table, meta_data, primary_keys, target_sf_columns):
#     glue_context = meta_data.get('glue_context')
#     snowflake_connection_name = meta_data.get('snowflake_connection_name')
#     snowflake_database = meta_data.get('snowflake_database')
#     # sf_meta_data = Transform.get_sf_meta(glue_context, snowflake_connection_name, snowflake_database, schema_table, object_name)
#     pre_action, target_sf_columns = Transform.create_missing_columns(df.drop('op'), target_sf_columns, schema_table, object_name)
#     merge_query = Transform.get_merge_query(schema_table, object_name, primary_keys, df.columns)
#     schema = schema_table.split('.')[0].upper()
#     tbl = schema_table.split('.')[1].upper()
#     post_action = merge_query + f'DROP TABLE IF EXISTS "{schema}"."{tbl}_stage";'.upper()
#     Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database, f'"{schema}"."{tbl}_stage"'.upper(),
#                              object_name,
#                              pre_action, post_action)
#     return target_sf_columns


def perform_merge_or_fresh_load(available_sf_table, schema_table, df, object_name, meta_data, primary_keys, target_sf_columns,target_sf_data_types):


    glue_context = meta_data.get('glue_context')
    snowflake_connection_name = meta_data.get('snowflake_connection_name')
    snowflake_database = meta_data.get('snowflake_database')
    support_schema = meta_data.get('snowflake_support_schema')
    spark = meta_data.get('spark')
    if schema_table in available_sf_table:
        print_message(f"[{schema_table}]  [{object_name}]    Table already present. Merge the data")
        target_sf_columns = merge_data(df, object_name, schema_table, meta_data, primary_keys, target_sf_columns,target_sf_data_types)
    else:
        print_message(f"[{schema_table}]  [{object_name}]    Table not present. Load fresh data")
        schema_name = schema_table.split('.')[0]
        temp_schema_table = f'"{support_schema}"."{schema_name}_temp"'.upper()
        schema = schema_table.split('.')[0].upper()
        tbl = schema_table.split('.')[1].upper()
        temp_post_action = f'CREATE SCHEMA IF NOT EXISTS "{schema}"; DROP TABLE IF EXISTS {temp_schema_table};'.upper()
        temp_df = spark.createDataFrame([{"id": 1}])
        Write.write_sf_dataframe(glue_context, snowflake_connection_name, temp_df, snowflake_database,
                                 temp_schema_table, object_name,
                                 None, temp_post_action)
        Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                 f'"{schema}"."{tbl}"'.upper(), object_name,
                                 None, None)
        available_sf_table.add(schema_table)
        target_sf_columns = df.columns


    return available_sf_table, target_sf_columns


def clean_df(schema_table, object_name, df, primary_keys):
    df = Transform.add_synced_column(df)
    df = Transform.clean_column_name(schema_table, object_name, df)
    df = Transform.parse_invalid_dtypes(schema_table, object_name, df)
    df = Transform.parse_to_string(schema_table, object_name, df, primary_keys)
    return df


def perform_delete(available_sf_table, df, object_name, schema_table, meta_data, primary_keys):
    df_delete = df.where(df['op'] == 'D').drop('op')
    if df_delete.count() > 0:
        if schema_table in available_sf_table:
            glue_context = meta_data.get('glue_context')
            snowflake_connection_name = meta_data.get('snowflake_connection_name')
            snowflake_database = meta_data.get('snowflake_database')
            print_message(f"[{schema_table}]  [{object_name}]    Found delete records. count: {df_delete.count()}")
            delete_query = Transform.get_delete_query(schema_table, object_name, primary_keys)
            schema = schema_table.split('.')[0].upper()
            tbl = schema_table.split('.')[1].upper()
            post_action = delete_query + f'DROP TABLE IF EXISTS "{schema}"."{tbl}_delete_stage";'.upper()
            Write.write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database,
                                     f'"{schema}"."{tbl}_delete_stage"'.upper(), object_name,
                                     None, post_action)
        else:
            print_warning(
                f"[{schema_table}]  [{object_name}]    No Table found but received delete records. Since skipping delete ")

    else:
        print_warning(f"[{schema_table}]  [{object_name}]    No records found for delete")


def perform_full_load(schema_table, files, meta_data, available_sf_table, target_sf_columns, target_sf_data_types):
    s3_src_bucket_name = meta_data.get('s3_src_bucket_name')
    aws_region = meta_data.get('aws_region')
    spark = meta_data.get('spark')
    full_load_files = files.get('full_load', [])
    print_message(f'[{schema_table}]  Total files found for full load count : {len(full_load_files)}')
    if len(full_load_files) <= 0:
        print_warning(f"[{schema_table}]  No Files found for full load")
    for idx, object_name in enumerate(sorted(full_load_files)):
        print_message(f"[{schema_table}]  [{object_name}]    Started processing")
        df = Extract.read_dataframe_s3(spark, schema_table, s3_src_bucket_name, object_name)
        if df.count() > 0:
            primary_keys = get_primary_keys(meta_data, schema_table, object_name, df.drop('op'))
            df = Transform.get_unique_records(df, primary_keys)
            df = clean_df(schema_table, object_name, df, primary_keys)
            available_sf_table, target_sf_columns = perform_merge_or_fresh_load(available_sf_table, schema_table, df, object_name,
                                                             meta_data, primary_keys, target_sf_columns, target_sf_data_types)
        else:
            print_warning(f"[{schema_table}]  [{object_name}]    Empty file found")
        S3.move_s3_file(schema_table, s3_src_bucket_name, object_name, meta_data.get('s3_archive_bucket_name'),
                        object_name,
                        aws_region)
        print_message(f"[{schema_table}]  [{object_name}]    Completed processing")
    return available_sf_table, target_sf_columns


def perform_cdc(schema_table, files, meta_data, available_sf_table, target_sf_columns,target_sf_data_types):
    s3_src_bucket_name = meta_data.get('s3_src_bucket_name')
    aws_region = meta_data.get('aws_region')
    spark = meta_data.get('spark')
    incremental_load_files = files.get('incremental_load', [])
    print_message(f'[{schema_table}]  Total files found for cdc load. count : {len(incremental_load_files)}')
    if len(incremental_load_files) <= 0:
        print_warning(f"[{schema_table}]  No Files found for cdc load")
    #for idx, object_name in enumerate(sorted(incremental_load_files)):
    try:
        object_name = str(incremental_load_files)
        #df = Extract.read_dataframe_s3(spark, schema_table, s3_src_bucket_name, object_name, incremental_load_files)
        df = Extract.read_dataframe_s3_bulk(spark, schema_table, s3_src_bucket_name, incremental_load_files)
        if df.count() > 0:
            primary_keys = get_primary_keys(meta_data, schema_table, object_name, df.drop('op'))
            df = Transform.get_unique_records(df, primary_keys)
            df = clean_df(schema_table, object_name, df, primary_keys)
            if 'op' not in df.columns:
                df = df.withColumn('op', lit('I'))
            perform_delete(available_sf_table, df, object_name, schema_table, meta_data, primary_keys)
            df_upsert = df.where(df['op'] != 'D').drop('op')
            if df_upsert.count() > 0:
                print_message(f"[{schema_table}]  [{object_name}]    Found upsert records. count: {df_upsert.count()}")
                available_sf_table, target_sf_columns = perform_merge_or_fresh_load(available_sf_table, schema_table, df_upsert,
                                                                 object_name,
                                                                 meta_data, primary_keys, target_sf_columns,target_sf_data_types)
            else:
                print_warning(f"[{schema_table}]  [{object_name}]    No records found for upsert")
        else:
            print_warning(f"[{schema_table}]  [{object_name}]    Empty file found.")
        for idx, object_name in enumerate(sorted(incremental_load_files)):
            S3.move_s3_file(schema_table, s3_src_bucket_name, object_name, meta_data.get('s3_archive_bucket_name'),
                            object_name,
                            aws_region)
        # S3.move_s3_file(schema_table, s3_src_bucket_name, object_name, meta_data.get('s3_archive_bucket_name'),
        #                 object_name,
        #                 aws_region)
    except Exception as e:
        print_warning(f"Error processing file {object_name}: {e}")
        # Add custom error handling logic here, such as logging the error or raising it again


def perform_etl(schema_table, files, meta_data, sf_meta_data):
    try:
        print_message(f"[{schema_table}]  ETL Started")
        available_sf_table = meta_data.get('available_sf_table')
        schema_name = schema_table.split('.')[0]
        table_name = schema_table.split('.')[1]

        # Get column names and data types
        columns_data = sf_meta_data.where((col('table_schema') == schema_name.lower()) &
                                          (col('table_name') == table_name.lower())) \
            .select('column_name', 'data_type') \
            .collect()
        print_message(f"[{columns_data}]  completed...")
        #target_sf_columns = columns_data.select("column_name")
        #target_sf_data_types = columns_data.select("data_type")
        target_sf_columns = [row["column_name"] for row in columns_data]
        target_sf_data_types = [row["data_type"] for row in columns_data]
        print_message(f"[{columns_data}]  target_sf_columns-completed...")

        # Extract column names and data types into separate lists
        #target_sf_columns = columns_data.rdd.map(lambda row: row["column_name"]).collect()
        #target_sf_data_types = columns_data.rdd.map(lambda row: row["data_type"]).collect()

        print_message(f"[{schema_table}]  target_sf_columns: {target_sf_columns}")

        available_sf_table, target_sf_columns = perform_full_load(schema_table, files, meta_data, available_sf_table,
                                                                  target_sf_columns, target_sf_data_types)
        perform_cdc(schema_table, files, meta_data, available_sf_table, target_sf_columns, target_sf_data_types)

    except Exception as e:
        print_warning(f"Error in perform_etl for {schema_table}: {str(e)}")
        # Optionally raise the exception further if needed
        # raise
# def perform_etl(schema_table, files, meta_data, sf_meta_data):
#     print_message(f"[{schema_table}]  ETL Started")
#     available_sf_table = meta_data.get('available_sf_table')
#     schema_name = schema_table.split('.')[0]
#     table_name = schema_table.split('.')[1]
#     # Get column names and data types
#     columns_data = sf_meta_data.where((col('table_schema') == schema_name.lower()) &
#                                       (col('table_name') == table_name.lower())) \
#         .select('column_name', 'data_type') \
#         .collect()
#     # Extract column names and data types into separate lists
#     target_sf_columns = [row["column_name"] for row in columns_data]
#     target_sf_data_types = [row["data_type"] for row in columns_data]
#     #target_sf_columns = [row["column_name"] for row in sf_meta_data.where(col('table_schema') == schema_name.lower()).where(col('table_name') == table_name.lower()).collect()]
#     print_message(f"[{schema_table}]  target_sf_columns: {target_sf_columns}")
#     available_sf_table, target_sf_columns = perform_full_load(schema_table, files, meta_data, available_sf_table, target_sf_columns,target_sf_data_types)
#     perform_cdc(schema_table, files, meta_data, available_sf_table, target_sf_columns,target_sf_data_types)
