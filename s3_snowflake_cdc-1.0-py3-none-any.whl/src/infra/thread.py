import concurrent.futures
import traceback

from src.util.python_util import print_error


class Threading:

    @staticmethod
    def parallelism(target_function, thread_count, all_files, meta_data, sf_meta_data):
        exception_list = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=thread_count) as executor:
            future_to_function = {
                executor.submit(target_function, schema_table, files, meta_data, sf_meta_data):
                    (schema_table, files) for schema_table, files in all_files.items()}
            for future in concurrent.futures.as_completed(future_to_function):
                result = future_to_function[future]
                try:
                    future.result()
                except Exception as exc:
                    print_error('%r generated an exception: %s' % (result[0], exc) + "\n")
                    exception_list.append('%r generated an exception: %s' % (result[0], exc))
                    traceback.print_exc()
        if len(exception_list) > 0:
            print_error(f"Got {len(exception_list)} exceptions")
            raise Exception(f"Got {len(exception_list)} exceptions", exception_list)

    @staticmethod
    def parallelism_for_validation(target_function, thread_count, table_list, meta_data):
        exception_list = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=thread_count) as executor:
            future_to_function = {
                executor.submit(target_function, source_table, source_table, meta_data):
                    source_table for source_table in table_list}
            for future in concurrent.futures.as_completed(future_to_function):
                result = future_to_function[future]
                try:
                    future.result()
                except Exception as exc:
                    print_error('%r generated an exception: %s' % (result[0], exc) + "\n")
                    exception_list.append('%r generated an exception: %s' % (result[0], exc))
                    traceback.print_exc()
        return exception_list

    @staticmethod
    def parallelism_for_missing_table(target_function, thread_count, table_list, meta_data):
        exception_list = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=thread_count) as executor:
            future_to_function = {
                executor.submit(target_function, source_table, meta_data):
                    source_table for source_table in table_list}
            for future in concurrent.futures.as_completed(future_to_function):
                result = future_to_function[future]
                try:
                    future.result()
                except Exception as exc:
                    print_error('%r generated an exception: %s' % (result[0], exc) + "\n")
                    exception_list.append('%r generated an exception: %s' % (result[0], exc))
                    traceback.print_exc()
        return exception_list

