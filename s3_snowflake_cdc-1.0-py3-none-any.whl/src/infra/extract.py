import boto3
import pandas as pd
from io import StringIO


from src.util.python_util import print_message


class Extract:

    @staticmethod
    def read_dataframe_s3(spark, schema_table, bucket_name, s3_key):
        file_path = f"s3a://{bucket_name}/{s3_key}"
        print_message(f"[{schema_table}]  [{s3_key}]    Reading S3 file {file_path}")
        #df = spark.read.option("header", "true").option('datetimeRebaseMode', 'CORRECTED').option('inferSchema',
        #                                                                                          True).parquet(
        #    file_path)
        #print_message(f"[{schema_table}]  [{s3_key}]    S3 file df count {df.count()}")
        #return df
        try:
            df = spark.read.option("header", "true").option('datetimeRebaseMode', 'CORRECTED').option('inferSchema',
                                                                                                  True).parquet(
                file_path)
            print_message(f"[{schema_table}]  [{s3_key}]    S3 file df count {df.count()}")
            return df
        except Exception as e:
            print_message(f"[{schema_table}]  [{s3_key}]    Error reading S3 file on function read_dataframe_s3: {str(e)}")
            # Handle schema mismatch or other errors here

    @staticmethod
    def read_dataframe_s3_bulk(spark, schema_table, bucket_name, incremental_load_files):
        file_paths = []
        for s3_key in incremental_load_files:
            file_paths.append(f"s3a://{bucket_name}/{s3_key}")
        print_message(f"[{schema_table}]    Reading S3 file {file_paths}")
        try:
            df = spark.read.option("header", "true").option('datetimeRebaseMode', 'CORRECTED').option('inferSchema',
                                                                                                  True).parquet(
                *file_paths)
            print_message(f"[{schema_table}]    S3 files df count {df.count()}")



            return df
        except Exception as e:
            print_message(f"[{schema_table}]    Error reading S3 files on function read_dataframe_s3_bulk : {str(e)}")
        #df = spark.read.option("header", "true").option('datetimeRebaseMode', 'CORRECTED').option('inferSchema',
        #                                                                                          True).parquet(
        #    *file_paths)
        #print_message(f"[{schema_table}]    S3 file df count {df.count()}")
        #return df

    @staticmethod
    def read_sf_query(glue_context, snowflake_connection_name, snowflake_database, query):
        print_message("Reading Snowflake query started")
        dynamic_frame = glue_context.create_dynamic_frame.from_options(
            connection_type="snowflake",
            connection_options={
                "autopushdown": "on",
                "query": query,
                "connectionName": snowflake_connection_name,
                "sfDatabase": snowflake_database,
            },
            transformation_ctx="dynamic_frame",
        )

        df = dynamic_frame.toDF()
        print_message(f"Reading Snowflake query completed, df count: {df.count()}")

        return df

    @staticmethod
    def read_sf_dataframe(glue_context, snowflake_connection_name, snowflake_database, schema, table):
        print_message("Reading Snowflake table started")
        dynamic_frame = glue_context.create_dynamic_frame.from_options(
            connection_type="snowflake",
            connection_options={
                "autopushdown": "on",
                "dbtable": table,
                "connectionName": snowflake_connection_name,
                "sfDatabase": snowflake_database,
                "sfSchema": schema,
            },
            transformation_ctx="dynamic_frame",
        )

        df = dynamic_frame.toDF()
        print_message(f"Reading Snowflake table completed, df count: {df.count()}")
        return df

    # @staticmethod
    # def read_mysql_query(glue_context, mysql_connection_name, query):
    #     #TODO
    #     print_message("Reading Snowflake query started")
    #     dynamic_frame = glue_context.create_dynamic_frame.from_options(
    #         connection_type="mysql",
    #         connection_options={
    #             "query": query,
    #             "connectionName": mysql_connection_name
    #         },
    #         transformation_ctx="dynamic_frame",
    #     )
    #
    #     df = dynamic_frame.toDF()
    #     print_message(f"Reading Snowflake query completed, df count: {df.count()}")
    #
    #     return df
    @staticmethod
    def read_mysql_query(glue_context, mysql_connection_name, query, schema_table):
        print_message("Reading Snowflake query started")
        dynamic_frame = glue_context.create_dynamic_frame.from_options(
            connection_type="mysql",
            connection_options={
                "useConnectionProperties": "true",
                "sampleQuery": query,
                "dbtable": schema_table,
                "connectionName": mysql_connection_name
            },
            transformation_ctx="dynamic_frame",
        )

        df = dynamic_frame.toDF()
        print_message(f"Reading Snowflake query completed, df count: {df.count()}")

        return df
    @staticmethod
    def read_mysql_dataframe(glue_context, mysql_connection_name, schema_table):
        print_message("Reading MySQL table started")
        dynamic_frame = glue_context.create_dynamic_frame.from_options(
            connection_type="mysql",
            connection_options={
                "useConnectionProperties": "true",
                "dbtable": schema_table,
                "connectionName": mysql_connection_name
            },
            transformation_ctx="dynamic_frame",
        )

        df = dynamic_frame.toDF()
        print_message(f"Reading MySQL table completed, df count: {df.count()}")
        return df