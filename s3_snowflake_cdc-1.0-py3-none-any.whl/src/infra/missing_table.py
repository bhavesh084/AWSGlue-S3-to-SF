import time
from datetime import datetime
from src.infra.extract import Extract
from src.infra.transform import Transform
from src.infra.write import Write
from src.util.python_util import print_message, print_warning


def get_primary_keys(meta_data, schema_table, df):
    table_join_keys = meta_data.get('table_join_keys')
    primary_keys = []
    if table_join_keys:
        table_name = schema_table.split('.')[1].lower()
        primary_keys = table_join_keys.get(table_name)
    if not primary_keys:
        primary_keys = Transform.auto_detect_id_column(df)
        print_warning(
            f"[{schema_table}]    primary_keys not found. so auto detected primary_keys is {primary_keys}")
    else:
        print_message(f"[{schema_table}]    given primary_keys {primary_keys}")
    return primary_keys


def clean_df(schema_table, object_name, df, primary_keys):
    df = Transform.add_record_change_synced_column(df)
    df = Transform.clean_column_name(schema_table, object_name, df)
    df = Transform.parse_invalid_dtypes(schema_table, object_name, df)
    df = Transform.parse_to_string(schema_table, object_name, df, primary_keys)
    return df


def perform_missing_table(source_schema_table, meta_data):
    glue_context = meta_data.get('glue_context')
    mysql_connection_name = meta_data.get('mysql_connection_name')
    snowflake_connection_name = meta_data.get('snowflake_connection_name')
    snowflake_database = meta_data.get('snowflake_database')

    print_message(f"Performing MySQL to SF Load: {source_schema_table}")
    try:
        source_df = Extract.read_mysql_dataframe(glue_context, mysql_connection_name, source_schema_table)
        source_count = source_df.count()
        print_message(f"Count for source: {source_schema_table} ==> count: {source_count}")
        target_schema_table = source_schema_table
        primary_keys = get_primary_keys(meta_data, target_schema_table, source_df)
        source_df = clean_df(target_schema_table, target_schema_table, source_df, primary_keys).cache()
        target_schema = target_schema_table.split(".")[0].upper()
        target_table = target_schema_table.split(".")[1].upper()
        post_action = f'drop table if exists "{target_schema}"."{target_table}"; create table "{target_schema}"."{target_table}" as select * from "{target_schema}"."{target_table}_MISSING_STAGE"; drop table if exists "{target_schema}"."{target_table}_MISSING_STAGE";'
        Write.write_sf_dataframe(glue_context, snowflake_connection_name, source_df, snowflake_database,
                                 f'"{target_schema}"."{target_table}_MISSING_STAGE"', f'"{target_schema}"."{target_table}_MISSING_STAGE"', None,
                                 post_action)
        print_message(f"MySQL to SF Load completed {source_schema_table}")

    except Exception as e:
        if f"java.sql.SQLSyntaxErrorException: Table '{source_schema_table}' doesn't exist".lower() in str(e).lower():
            print_warning(f'Source table does not exits {source_schema_table}')
        elif f"Unknown database '{source_schema_table.split('.')[0]}'".lower() in str(e).lower():
            print_warning(f"Source database '{source_schema_table.split('.')[0]}' does not exits {source_schema_table}")
        elif f"java.sql.SQLSyntaxErrorException: Table '{source_schema_table}' doesn't exist" in str(e).lower():
            print_warning(f'Source table does not exits {source_schema_table}')
        else:
            raise e
