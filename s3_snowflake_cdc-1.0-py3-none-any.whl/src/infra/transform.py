from src.util.python_util import print_error, print_message
from pyspark.sql.functions import *
from pyspark.sql.window import Window


class Transform:

    @staticmethod
    def clean_column_name(schema_table, object_name, df):
        print_message(f"[{schema_table}]  [{object_name}]    Cleaning the column names")
        df = df.toDF(
            *[col_name.lower().replace(' ', '_').replace('.', '').replace('@', '').strip() for col_name in df.columns])
        return df

    @staticmethod
    def get_merge_query(schema_table, object_name, primary_keys, source_columns):
        schema_name = schema_table.split('.')[0]
        table_name = schema_table.split('.')[1]
        print_message(
            f"[{schema_table}]  [{object_name}]    Fetching merge query, primary_keys: {primary_keys}, source_columns: {source_columns}")
        if primary_keys:
            update_set_clause = ", ".join([f"target.\"{s_column}\" = source.\"{s_column}\"" if s_column[
                0].isdigit() else f"target.{s_column} = source.{s_column}" for s_column in source_columns])
            tgt_columns = ", ".join(
                [f"\"{s_column}\"" if s_column[0].isdigit() else s_column for s_column in source_columns])
            insert_values_clause = ", ".join(
                [f"source.\"{s_column}\"" if s_column[0].isdigit() else f"source.{s_column}" for s_column in
                 source_columns])

            source_keys = ', '.join(
                ['source.\"' + key + '\"' if key[0].isdigit() else 'source.' + key for key in primary_keys])
            target_keys = ', '.join(
                ['target.\"' + key + '\"' if key[0].isdigit() else 'target.' + key for key in primary_keys])

            statement = f"""
            ALTER SESSION SET ERROR_ON_NONDETERMINISTIC_MERGE = FALSE;
            
            MERGE INTO "{schema_name.upper()}"."{table_name.upper()}" AS target
            USING "{schema_name.upper()}"."{table_name.upper()}_STAGE" AS source
            ON ({target_keys}) = ({source_keys})
            WHEN MATCHED THEN
                UPDATE SET
                    {update_set_clause}
            WHEN NOT MATCHED THEN
                INSERT ({tgt_columns}) VALUES ({insert_values_clause});
            """
            return statement
        else:
            print_error(f"[{schema_table}]  [{object_name}]    No join key found for table {schema_name}.{table_name}")
            raise ValueError(f"[{schema_table}]  [{object_name}]    Please define primary key for {schema_name}.{table_name}")

    @staticmethod
    def get_delete_query(schema_table, object_name, primary_keys):
        print_message(
            f"[{schema_table}]  [{object_name}]    Fetching delete query, primary_keys: {primary_keys}")
        if primary_keys:
            primary_keys = ", ".join(
                [f"\"{s_column}\"" if s_column[0].isdigit() else s_column for s_column in primary_keys])
            schema = schema_table.split('.')[0].upper()
            tbl = schema_table.split('.')[1].upper()
            delete_sql = f'delete from "{schema}"."{tbl}" where ({primary_keys}) IN (select {primary_keys} from "{schema}"."{tbl}_delete_stage");'.upper()
            return delete_sql
        else:
            print_error(f"[{schema_table}]  [{object_name}]    No join key found for table {schema_table}")
            raise ValueError(f"[{schema_table}]  [{object_name}]    Please define primary key for {schema_table}")

    @staticmethod
    def auto_detect_id_column(df):
        if 'id' in df.columns:
            return ['id']
        id_columns = [col for col in df.columns if col.endswith('_id')]
        if id_columns:
            return id_columns[:1]
        return [df.columns[0] if df.columns[0] != 'recordchangedate' else df.columns[1]]



    @staticmethod
    def parse_invalid_dtypes(schema_table, object_name, df):
        column_types = df.dtypes
        print_message(f'[{schema_table}]  [{object_name}]    parsing invalid dtypes. column_types {column_types}')

        expected_data_types = ['int', 'bigint', 'float', 'double', 'string', 'timestamp', 'boolean']
        invalid_dtype_columns = [(col_name, col_type) for col_name, col_type in column_types if
                                 col_type not in expected_data_types]

        for col_name, col_type in invalid_dtype_columns:
            if not str(col_type).startswith('decimal('):
                print_message(f'[{schema_table}]  [{object_name}]    invalid_dtype_column {col_name} : {col_type}')
                df = df.withColumn(col_name, concat_ws(",", col(col_name)))

        return df



    @staticmethod
    def create_missing_columns(df, target_sf_columns, schema_table, object_name):
        print_message(f"[{schema_table}]  [{object_name}]    Checking if any new column {schema_table}")
        schema_name = schema_table.split('.')[0]
        table_name = schema_table.split('.')[1]
        source_columns = df.columns
        target_columns = target_sf_columns
        print_message(f"[{schema_table}]  [{object_name}]    source_columns: {source_columns}")
        print_message(f"[{schema_table}]  [{object_name}]    target_columns: {target_columns}")
        added_columns = set(source_columns) - set(target_columns)
        print_message(f"[{schema_table}]  [{object_name}]    Added Columns: {added_columns}")
        if added_columns:
            data_type_mapping = dict(df.dtypes)
            spark_sf_dtype = {'int': 'INTEGER', 'bigint': 'BIGINT', 'float': 'DECIMAL', 'double': 'DOUBLE',
                              'string': 'TEXT', 'timestamp': 'TIMESTAMP', 'boolean': 'BOOLEAN'}
            column_data_type_mapping = {added_column: spark_sf_dtype.get(data_type_mapping.get(added_column),
                                                                         data_type_mapping.get(added_column)) for
                                        added_column in added_columns}

            alter_statements = ", ".join(
                [f"\"{add_column}\" {data_type}" if add_column[0].isdigit() else f"{add_column} {data_type}" for add_column, data_type in column_data_type_mapping.items()])
            full_alter_statement = f'ALTER TABLE "{schema_name}"."{table_name}" ADD COLUMN {alter_statements};'.upper()
            target_sf_columns.extend(added_columns)
            return full_alter_statement, target_sf_columns
        else:
            print_message(f"[{schema_table}]  [{object_name}]    No Column to add")
            return None, target_sf_columns


    @staticmethod
    def add_synced_column(df):
        df = df.withColumn("_synced_at", current_timestamp())
        return df

    @staticmethod
    def get_unique_records(df, primary_keys):
        window_spec = Window.partitionBy(primary_keys).orderBy(col("recordchangedate").desc())
        window_df = df.withColumn("row_number", row_number().over(window_spec))
        filtered_df = window_df.filter(col("row_number") == 1).drop("row_number")
        return filtered_df

    @staticmethod
    def parse_to_string(schema_table, object_name, df, primary_keys):
        print_message(f"[{schema_table}]  [{object_name}]    Parsing df columns to string {schema_table}")
        #column_types = df.dtypes
        #print_message(f" Patel {column_types}  Patel")
        #column_names_except_timestamp = [col_name for col_name, col_type in column_types if col_type != 'timestamp' and col_type != 'bigint' and col_type != 'smallint' and col_type != 'tinyint']
        #string_columns = list(set(column_names_except_timestamp) - set(primary_keys))
        #print_message(f"[{schema_table}]  [{object_name}]    string_columns {string_columns}")
        #for str_col in string_columns:
        #    df = df.withColumn(str_col, col(str_col).cast("string"))
        return df

    @staticmethod
    def add_record_change_synced_column(df):
        df = df.withColumn("recordchangedate", current_timestamp())
        df = df.withColumn("_synced_at", current_timestamp())
        return df


