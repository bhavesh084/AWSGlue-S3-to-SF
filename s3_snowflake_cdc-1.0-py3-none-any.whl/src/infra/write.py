from src.util.python_util import print_message

try:
    from awsglue import DynamicFrame
except Exception as e:
    pass

class Write:

    @staticmethod
    def write_sf_dataframe(glue_context, snowflake_connection_name, df, snowflake_database, schema_table, object_name, pre_action=None,
                           post_action=None):
        print_message(f"[{schema_table}]  [{object_name}]    Writing Snowflake table started, df count: {df.count()}")
        schema = schema_table.split('.')[0]
        table = schema_table.split('.')[1]

        dynamic_frame = DynamicFrame.fromDF(df, glue_context, "dynamic_frame")

        connection_options = {
            "autopushdown": "on",
            "dbtable": table,
            "connectionName": snowflake_connection_name,
            "sfDatabase": snowflake_database,
            "sfSchema": schema
        }

        if pre_action is not None:
            connection_options['preactions'] = pre_action
        if post_action is not None:
            connection_options['postactions'] = post_action

        glue_context.write_dynamic_frame.from_options(
            frame=dynamic_frame,
            connection_type="snowflake",
            connection_options=connection_options,
            transformation_ctx="dynamic_frame",
        )
        print_message(f"[{schema_table}]  [{object_name}]    Writing Snowflake table completed")
